package com.example.ChalkBoard

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MemberRoleTypeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_member_role_type)
    }
}